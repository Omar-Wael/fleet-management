import { ColumnMapping } from './column-mapping.util';
import { MaintenanceCategory, Technician, Vehicle, WorkOrder } from '../../core/models/fleet.models';

// =====================================================================
// Predefined column mappings, one per tab that supports bulk import
// (per the spec: Vehicles and Maintenance both have "Dual Input: Manual +
// Excel/PDF/Word"). Add more headers to each `headers` array as you learn
// the actual column labels your source spreadsheets/PDFs use — matching
// is case-insensitive and whitespace-trimmed, so exact casing doesn't matter.
//
// NOTE: these maps only cover columns that are plain scalars on the target
// table. Foreign-key columns (vehicle_type_id, operating_department_id,
// maintenance_workshop_id, current_engine_id) are intentionally NOT in the
// map — you can't reliably import a UUID from a spreadsheet. Instead, map
// the *name* column (e.g. "Vehicle Type") to a plain string field first,
// then resolve name -> id via a lookup table before calling
// vehiclesService.bulkUpsert(). See resolveVehicleForeignKeys() below for
// the resolver pattern.
// =====================================================================

/** Intermediate shape produced directly from the spreadsheet, before FK resolution. */
export interface VehicleImportRow {
  plate_number: string;
  vehicle_type_name: string;
  operating_department_name: string | null;
  make: string | null;
  model: string | null;
  manufacture_year: number | null;
  chassis_number: string | null;
  odometer_km: number | null;
  color: string | null;
  engine_serial_number: string | null;
  notes: string | null;
}

export const VEHICLE_IMPORT_MAP: ColumnMapping<VehicleImportRow> = {
  plate_number: { headers: ['Plate Number', 'رقم اللوحة'], required: true },
  vehicle_type_name: { headers: ['Vehicle Type', 'نوع السيارة'], required: true },
  operating_department_name: { headers: ['Operating Dept', 'Operating Department', 'الإدارة المشغلة'] },
  make: { headers: ['Make', 'الشركة المصنعة'] },
  model: { headers: ['Model', 'الموديل'] },
  manufacture_year: { headers: ['Manufacture Year', 'Year', 'سنة الصنع'], type: 'number' },
  chassis_number: { headers: ['Chassis No.', 'Chassis Number', 'رقم الشاسيه'] },
  odometer_km: { headers: ['Odometer', 'Odometer (KM)', 'قراءة العداد'], type: 'number' },
  color: { headers: ['Color', 'اللون'] },
  engine_serial_number: { headers: ['Engine No.', 'Engine Serial Number', 'رقم المحرك'] },
  notes: { headers: ['Notes', 'ملاحظات'] },
};

/**
 * Resolves the name-based fields from VehicleImportRow into the
 * FK-id-based fields vehiclesService.bulkUpsert() expects. Call this
 * after importExcelWithMapping()/importFileWithMapping() and before
 * bulkUpsert() — pass in lookup maps built once per import session
 * (e.g. from vehicleTypesService.list(), departmentsService.list(),
 * enginesService.list()).
 */
export function resolveVehicleForeignKeys(
  rows: VehicleImportRow[],
  lookups: {
    vehicleTypeIdByName: Map<string, string>;
    departmentIdByName: Map<string, string>;
    engineIdBySerial: Map<string, string>;
    defaultMaintenanceWorkshopId: string; // required column on vehicles; ask the user to pick one for the whole batch, or add a "Repair Dept" column to VehicleImportRow and resolve it the same way
  }
): { resolved: Partial<Vehicle>[]; unresolved: { row: VehicleImportRow; reason: string }[] } {
  const resolved: Partial<Vehicle>[] = [];
  const unresolved: { row: VehicleImportRow; reason: string }[] = [];

  for (const row of rows) {
    const vehicleTypeId = lookups.vehicleTypeIdByName.get(row.vehicle_type_name.trim().toLowerCase());
    if (!vehicleTypeId) {
      unresolved.push({ row, reason: `Unknown vehicle type: "${row.vehicle_type_name}"` });
      continue;
    }

    resolved.push({
      plate_number: row.plate_number,
      vehicle_type_id: vehicleTypeId,
      operating_department_id: row.operating_department_name
        ? lookups.departmentIdByName.get(row.operating_department_name.trim().toLowerCase()) ?? null
        : null,
      maintenance_workshop_id: lookups.defaultMaintenanceWorkshopId,
      current_engine_id: row.engine_serial_number
        ? lookups.engineIdBySerial.get(row.engine_serial_number.trim().toLowerCase()) ?? null
        : null,
      make: row.make,
      model: row.model,
      manufacture_year: row.manufacture_year,
      chassis_number: row.chassis_number,
      odometer_km: row.odometer_km ?? 0,
    });
  }

  return { resolved, unresolved };
}

// ---------------------------------------------------------------------
// Maintenance tab (Work Orders) import
// ---------------------------------------------------------------------

export interface WorkOrderImportRow {
  plate_number: string;
  description: string;
  repair_types: string; // comma-separated in the spreadsheet, split below
  maintenance_categories: string; // comma-separated
  odometer_km_at_service: number | null;
  opened_at: string | null;
}

export const WORK_ORDER_IMPORT_MAP: ColumnMapping<WorkOrderImportRow> = {
  plate_number: { headers: ['Plate No.', 'Plate Number', 'رقم اللوحة'], required: true },
  description: { headers: ['Repair Description', 'Description', 'وصف الإصلاح'], required: true },
  repair_types: { headers: ['Repair Type', 'نوع الإصلاح'] },
  maintenance_categories: { headers: ['Maintenance Category', 'فئة الصيانة'] },
  odometer_km_at_service: { headers: ['Odometer', 'قراءة العداد'], type: 'number' },
  opened_at: { headers: ['Date', 'Opened At', 'التاريخ'], type: 'date' },
};

/** Resolves plate_number -> vehicle_id and splits the comma-separated tag columns, ready for maintenanceService.create(). */
export function resolveWorkOrderForeignKeys(
  rows: WorkOrderImportRow[],
  vehicleIdByPlate: Map<string, string>
): { resolved: Partial<WorkOrder & { vehicle_id: string }>[]; unresolved: { row: WorkOrderImportRow; reason: string }[] } {
  const resolved: Partial<WorkOrder & { vehicle_id: string }>[] = [];
  const unresolved: { row: WorkOrderImportRow; reason: string }[] = [];

  for (const row of rows) {
    const vehicleId = vehicleIdByPlate.get(row.plate_number.trim().toLowerCase());
    if (!vehicleId) {
      unresolved.push({ row, reason: `Unknown plate number: "${row.plate_number}"` });
      continue;
    }

    resolved.push({
      vehicle_id: vehicleId,
      description: row.description,
      repair_types: row.repair_types ? row.repair_types.split(',').map((s) => s.trim()) : [],
      maintenance_categories: row.maintenance_categories
        ? (row.maintenance_categories.split(',').map((s) => s.trim().toLowerCase()) as MaintenanceCategory[])
        : [],
      odometer_km_at_service: row.odometer_km_at_service ?? undefined,
      opened_at: row.opened_at ?? undefined,
    });
  }

  return { resolved, unresolved };
}

// ---------------------------------------------------------------------
// Technicians tab import
// ---------------------------------------------------------------------

export interface TechnicianImportRow {
  full_name: string;
  national_id: string | null;
  specialty: string | null;
  workshop_name: string | null;
  phone: string | null;
  hire_date: string | null;
}

export const TECHNICIAN_IMPORT_MAP: ColumnMapping<TechnicianImportRow> = {
  full_name: { headers: ['Full Name', 'Name', 'الاسم بالكامل', 'الاسم'], required: true },
  national_id: { headers: ['National ID', 'الرقم القومي'] },
  specialty: { headers: ['Specialty', 'التخصص'] },
  workshop_name: { headers: ['Workshop', 'ورشة العمل', 'الورشة'] },
  phone: { headers: ['Phone', 'رقم الهاتف', 'الهاتف'] },
  hire_date: { headers: ['Hire Date', 'تاريخ التعيين'], type: 'date' },
};

/**
 * Resolves workshop_name -> workshop_id (best effort, left null if no
 * match — workshop_id is optional on technicians, unlike the required
 * maintenance_workshop_id on vehicles, so there's no need for a
 * mandatory "pick a default workshop" step before importing).
 */
export function resolveTechnicianForeignKeys(
  rows: TechnicianImportRow[],
  workshopIdByName: Map<string, string>
): { resolved: Partial<Technician>[]; unresolved: { row: TechnicianImportRow; reason: string }[] } {
  const resolved: Partial<Technician>[] = [];
  const unresolved: { row: TechnicianImportRow; reason: string }[] = [];

  for (const row of rows) {
    if (!row.full_name?.trim()) {
      unresolved.push({ row, reason: 'Missing full name' });
      continue;
    }

    const workshopId = row.workshop_name
      ? workshopIdByName.get(row.workshop_name.trim().toLowerCase()) ?? null
      : null;

    resolved.push({
      full_name: row.full_name.trim(),
      national_id: row.national_id || null,
      specialty: row.specialty || null,
      workshop_id: workshopId,
      phone: row.phone || null,
      hire_date: row.hire_date || null,
      is_active: true,
    });
  }

  return { resolved, unresolved };
}

/** Header row for the downloadable Technicians import template — matches the first (English) variant of each TECHNICIAN_IMPORT_MAP field. */
export const TECHNICIAN_IMPORT_TEMPLATE_HEADERS = [
  'Full Name',
  'National ID',
  'Specialty',
  'Workshop',
  'Phone',
  'Hire Date',
];
