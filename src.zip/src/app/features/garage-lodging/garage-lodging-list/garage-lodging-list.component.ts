import { DatePipe, DecimalPipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { GarageLodgingFormComponent } from '../garage-lodging-form/garage-lodging-form.component';

import {
  GarageLodgingService,
  GarageLodgingGridRow,
} from '../../../core/services/garage-lodging.service';
import { VehiclesService } from '../../../core/services/vehicles.service';
import { VGarageVisitsThisYear, VehicleWithLookups } from '../../../core/models/fleet.models';
import { exportToExcel, ExcelExportColumn } from '../../../shared/utils/excel-import-export.util';
import { downloadGridReportPdf, PdfReportColumn } from '../../../shared/utils/pdf-report.util';

@Component({
  selector: 'app-garage-lodging-list',
  standalone: true,
  imports: [DatePipe, FormsModule, GarageLodgingFormComponent],
  templateUrl: './garage-lodging-list.component.html',
  styleUrls: ['./garage-lodging-list.component.scss'],
})
export class GarageLodgingListComponent implements OnInit {
  lodgings: GarageLodgingGridRow[] = [];
  vehicles: VehicleWithLookups[] = [];
  loading = true;
  loadError: string | null = null;

  searchTerm = '';
  openOnly = false;
  vehicleFilter = '';

  vehicleStat: VGarageVisitsThisYear | null = null;
  vehicleStatLoading = false;

  formOpen = false;

  checkingOutId: string | null = null;
  checkOutError: string | null = null;

  constructor(
    private garageLodgingService: GarageLodgingService,
    private vehiclesService: VehiclesService,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.vehiclesService.list().subscribe({ next: (vehicles) => (this.vehicles = vehicles) });
    this.loadLodgings();
  }

  loadLodgings(): void {
    this.loading = true;
    this.loadError = null;

    this.garageLodgingService.list(this.vehicleFilter || undefined).subscribe({
      next: (lodgings) => {
        this.lodgings = lodgings;
        this.loading = false;
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.loadError = err instanceof Error ? err.message : 'Failed to load garage lodgings.';
        this.loading = false;
        this.cdr.markForCheck();
      },
    });
  }

  onVehicleFilterChange(): void {
    this.loadLodgings();

    if (!this.vehicleFilter) {
      this.vehicleStat = null;
      return;
    }

    this.vehicleStatLoading = true;
    this.garageLodgingService.getVisitsThisYear(this.vehicleFilter).subscribe({
      next: (stat) => {
        this.vehicleStat = stat;
        this.vehicleStatLoading = false;
      },
      error: () => {
        this.vehicleStat = null;
        this.vehicleStatLoading = false;
      },
    });
  }

  get filteredLodgings(): GarageLodgingGridRow[] {
    const term = this.searchTerm.trim().toLowerCase();

    return this.lodgings.filter((l) => {
      if (this.openOnly && l.exit_date) return false;
      if (!term) return true;
      const haystack = [l.vehicles?.plate_number, l.garage_locations?.garage_name, l.reason]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return haystack.includes(term);
    });
  }

  openCheckInForm(): void {
    this.formOpen = true;
  }

  onFormClosed(): void {
    this.formOpen = false;
  }

  onFormSaved(): void {
    this.formOpen = false;
    this.loadLodgings();
  }

  checkOut(lodging: GarageLodgingGridRow): void {
    const confirmed = window.confirm(
      `Check out "${lodging.vehicles?.plate_number}" from the garage today?`,
    );
    if (!confirmed) return;

    this.checkingOutId = lodging.id;
    this.checkOutError = null;

    this.garageLodgingService.checkOut(lodging.id).subscribe({
      next: () => {
        this.checkingOutId = null;
        this.loadLodgings();
      },
      error: (err) => {
        this.checkingOutId = null;
        this.checkOutError = err instanceof Error ? err.message : 'Failed to check out vehicle.';
      },
    });
  }

  exportExcel(): void {
    exportToExcel(this.filteredLodgings, this.excelColumns(), 'garage-lodging-export');
  }

  exportPdf(): void {
    downloadGridReportPdf(
      this.filteredLodgings,
      this.pdfColumns(),
      {
        title: 'Garage Lodging Report',
        subtitle: `Generated ${new Date().toLocaleDateString()}`,
        orientation: 'landscape',
      },
      'garage-lodging-report',
    );
  }

  private excelColumns(): ExcelExportColumn<GarageLodgingGridRow>[] {
    return [
      { header: 'Vehicle', accessor: (l) => l.vehicles?.plate_number },
      { header: 'Garage', accessor: (l) => l.garage_locations?.garage_name },
      { header: 'Zone', accessor: (l) => l.garage_locations?.zone_label },
      { header: 'Reason', accessor: (l) => l.reason },
      { header: 'Entry Date', accessor: (l) => l.entry_date },
      { header: 'Exit Date', accessor: (l) => l.exit_date },
      { header: 'Duration (days)', accessor: (l) => l.duration_days },
    ];
  }

  private pdfColumns(): PdfReportColumn<GarageLodgingGridRow>[] {
    return [
      { header: 'Vehicle', accessor: (l) => l.vehicles?.plate_number },
      { header: 'Garage', accessor: (l) => l.garage_locations?.garage_name },
      { header: 'Entry Date', accessor: (l) => l.entry_date },
      { header: 'Status', accessor: (l) => (l.exit_date ? 'Closed' : 'Open') },
      { header: 'Duration (days)', accessor: (l) => l.duration_days },
    ];
  }
}
