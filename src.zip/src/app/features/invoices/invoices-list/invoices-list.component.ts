import { DatePipe, DecimalPipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { InvoiceFormComponent } from '../invoice-form/invoice-form.component';
import { InvoiceDetailDrawerComponent } from '../invoice-detail-drawer/invoice-detail-drawer.component';

import { InvoicesService, InvoiceGridRow } from '../../../core/services/invoices.service';
import { exportToExcel, ExcelExportColumn } from '../../../shared/utils/excel-import-export.util';
import { downloadGridReportPdf, PdfReportColumn } from '../../../shared/utils/pdf-report.util';

@Component({
  selector: 'app-invoices-list',
  standalone: true,
  imports: [DatePipe, DecimalPipe, FormsModule, InvoiceFormComponent, InvoiceDetailDrawerComponent],
  templateUrl: './invoices-list.component.html',
  styleUrls: ['./invoices-list.component.scss'],
})
export class InvoicesListComponent implements OnInit {
  invoices: InvoiceGridRow[] = [];
  loading = true;
  loadError: string | null = null;

  searchTerm = '';

  formOpen = false;
  editingInvoice: InvoiceGridRow | null = null;

  drawerOpen = false;
  selectedInvoice: InvoiceGridRow | null = null;

  constructor(
    private invoicesService: InvoicesService,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.loadInvoices();
  }

  loadInvoices(): void {
    this.loading = true;
    this.loadError = null;

    this.invoicesService.list().subscribe({
      next: (invoices) => {
        this.invoices = invoices;
        this.loading = false;
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.loadError = err instanceof Error ? err.message : 'Failed to load invoices.';
        this.loading = false;
        this.cdr.markForCheck();
      },
    });
  }

  get filteredInvoices(): InvoiceGridRow[] {
    const term = this.searchTerm.trim().toLowerCase();
    if (!term) return this.invoices;

    return this.invoices.filter((inv) => {
      const haystack = [inv.invoice_no, inv.external_workshops?.name, inv.invoice_source]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return haystack.includes(term);
    });
  }

  openCreateForm(): void {
    this.editingInvoice = null;
    this.formOpen = true;
  }

  onFormClosed(): void {
    this.formOpen = false;
  }

  onFormSaved(): void {
    this.formOpen = false;
    this.loadInvoices();
  }

  openDetail(invoice: InvoiceGridRow): void {
    this.selectedInvoice = invoice;
    this.drawerOpen = true;
  }

  onDrawerClosed(): void {
    this.drawerOpen = false;
  }

  onDrawerEdit(invoice: InvoiceGridRow): void {
    this.drawerOpen = false;
    this.editingInvoice = invoice;
    this.formOpen = true;
  }

  onDrawerDeleted(): void {
    this.drawerOpen = false;
    this.loadInvoices();
  }

  exportExcel(): void {
    exportToExcel(this.filteredInvoices, this.excelColumns(), 'invoices-export');
  }

  exportPdf(): void {
    downloadGridReportPdf(
      this.filteredInvoices,
      this.pdfColumns(),
      {
        title: 'Invoices Report',
        subtitle: `Generated ${new Date().toLocaleDateString()}`,
        orientation: 'landscape',
      },
      'invoices-report',
    );
  }

  private excelColumns(): ExcelExportColumn<InvoiceGridRow>[] {
    return [
      { header: 'Invoice No.', accessor: (i) => i.invoice_no },
      { header: 'Vendor', accessor: (i) => i.external_workshops?.name },
      { header: 'Invoice Date', accessor: (i) => i.invoice_date },
      { header: 'Subtotal', accessor: (i) => i.subtotal_value },
      { header: 'Tax', accessor: (i) => i.tax_value },
      { header: 'Discount', accessor: (i) => i.discount_value },
      { header: 'Total', accessor: (i) => i.total_value },
      { header: 'Notes', accessor: (i) => i.notes },
    ];
  }

  private pdfColumns(): PdfReportColumn<InvoiceGridRow>[] {
    return [
      { header: 'Invoice No.', accessor: (i) => i.invoice_no },
      { header: 'Vendor', accessor: (i) => i.external_workshops?.name },
      { header: 'Date', accessor: (i) => i.invoice_date },
      { header: 'Total', accessor: (i) => i.total_value },
    ];
  }
}
