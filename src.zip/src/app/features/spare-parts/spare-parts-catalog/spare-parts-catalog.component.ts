import { DecimalPipe } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { SparePartFormComponent } from '../spare-part-form/spare-part-form.component';
import { SparePartsService } from '../../../core/services/spare-parts.service';
import { SparePart } from '../../../core/models/fleet.models';
import { exportToExcel, ExcelExportColumn } from '../../../shared/utils/excel-import-export.util';
import { downloadGridReportPdf, PdfReportColumn } from '../../../shared/utils/pdf-report.util';

@Component({
  selector: 'app-spare-parts-catalog',
  standalone: true,
  imports: [DecimalPipe, FormsModule, SparePartFormComponent],
  templateUrl: './spare-parts-catalog.component.html',
  styleUrls: ['./spare-parts-catalog.component.scss'],
})
export class SparePartsCatalogComponent implements OnInit {
  parts: SparePart[] = [];
  loading = true;
  loadError: string | null = null;

  searchTerm = '';
  lowStockOnly = false;

  formOpen = false;
  editingPart: SparePart | null = null;

  constructor(
    private sparePartsService: SparePartsService,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.loadParts();
  }

  loadParts(): void {
    this.loading = true;
    this.loadError = null;

    this.sparePartsService.list().subscribe({
      next: (parts) => {
        this.parts = parts;
        this.loading = false;
        this.cdr.markForCheck();
      },
      error: (err) => {
        this.loadError = err instanceof Error ? err.message : 'Failed to load spare parts.';
        this.loading = false;
        this.cdr.markForCheck();
      },
    });
  }

  isLowStock(part: SparePart): boolean {
    return part.reorder_threshold != null && part.current_stock_qty <= part.reorder_threshold;
  }

  get filteredParts(): SparePart[] {
    const term = this.searchTerm.trim().toLowerCase();

    return this.parts.filter((p) => {
      if (this.lowStockOnly && !this.isLowStock(p)) return false;
      if (!term) return true;
      const haystack = [p.part_code, p.name_ar, p.name_en].filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(term);
    });
  }

  openAddForm(): void {
    this.editingPart = null;
    this.formOpen = true;
  }

  openEditForm(part: SparePart): void {
    this.editingPart = part;
    this.formOpen = true;
  }

  onFormClosed(): void {
    this.formOpen = false;
  }

  onFormSaved(): void {
    this.formOpen = false;
    this.loadParts();
  }

  exportExcel(): void {
    exportToExcel(this.filteredParts, this.excelColumns(), 'spare-parts-catalog');
  }

  exportPdf(): void {
    downloadGridReportPdf(
      this.filteredParts,
      this.pdfColumns(),
      {
        title: 'Spare Parts Catalog',
        subtitle: `Generated ${new Date().toLocaleDateString()}`,
        orientation: 'landscape',
      },
      'spare-parts-catalog',
    );
  }

  private excelColumns(): ExcelExportColumn<SparePart>[] {
    return [
      { header: 'Part Code', accessor: (p) => p.part_code },
      { header: 'Name (Arabic)', accessor: (p) => p.name_ar },
      { header: 'Name (English)', accessor: (p) => p.name_en },
      { header: 'Unit', accessor: (p) => p.unit },
      { header: 'Unit Cost', accessor: (p) => p.unit_cost },
      { header: 'Current Stock', accessor: (p) => p.current_stock_qty },
      { header: 'Reorder Threshold', accessor: (p) => p.reorder_threshold },
    ];
  }

  private pdfColumns(): PdfReportColumn<SparePart>[] {
    return [
      { header: 'Part Code', accessor: (p) => p.part_code },
      { header: 'Name', accessor: (p) => p.name_en || p.name_ar },
      { header: 'Unit', accessor: (p) => p.unit },
      { header: 'Unit Cost', accessor: (p) => p.unit_cost },
      { header: 'Stock', accessor: (p) => p.current_stock_qty },
      { header: 'Reorder At', accessor: (p) => p.reorder_threshold },
    ];
  }
}
