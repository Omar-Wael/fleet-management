import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SupabaseClientService } from '../../core/supabase/supabase-client.service';
import { fromSupabase } from '../../core/supabase/from-supabase.util';
import {
  GarageLocation,
  MaintenanceWorkshop,
  OperatingDepartment,
  VehicleType,
} from '../models/fleet.models';

/**
 * Small, mostly-static reference tables shared across several tabs
 * (dropdown options for forms, filter chips, and FK-name resolution
 * during bulk import — see utils/import-column-maps.ts). Deliberately
 * stateless like every other service here: components own caching if
 * they need it for a session (e.g. building a Map<name, id> once before
 * an import run).
 */
@Injectable({ providedIn: 'root' })
export class LookupsService {
  constructor(private supabaseClientService: SupabaseClientService) {}

  private get client() {
    return this.supabaseClientService.client;
  }

  listVehicleTypes(): Observable<VehicleType[]> {
    return fromSupabase<VehicleType[]>(
      this.client.from('vehicle_types').select('*').order('name_en', { ascending: true }),
    );
  }

  listOperatingDepartments(activeOnly = true): Observable<OperatingDepartment[]> {
    let query = this.client.from('operating_departments').select('*');
    if (activeOnly) query = query.eq('is_active', true);
    return fromSupabase<OperatingDepartment[]>(query.order('name_en', { ascending: true }));
  }

  listMaintenanceWorkshops(): Observable<MaintenanceWorkshop[]> {
    return fromSupabase<MaintenanceWorkshop[]>(
      this.client.from('maintenance_workshops').select('*').order('name_en', { ascending: true }),
    );
  }

  listGarageLocations(): Observable<GarageLocation[]> {
    return fromSupabase<GarageLocation[]>(
      this.client.from('garage_locations').select('*').order('garage_name', { ascending: true }),
    );
  }
}
